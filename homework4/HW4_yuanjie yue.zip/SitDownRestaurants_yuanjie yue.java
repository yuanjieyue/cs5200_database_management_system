package Review.model;


public class SitDownRestaurants extends Restaurants {

	protected int capacity;

	public SitDownRestaurants(String name, String description, String menu, String hours, boolean active,
			CuisineType cuisineType, String street1, String street2, String city, String state, int zip,
			Companies companyName, int capacity) {
		super(name, description, menu, hours, active, cuisineType, street1, street2, city, state, zip, companyName);
		this.capacity = capacity;
	}

	public SitDownRestaurants(int restaurantId) {
		super(restaurantId);
	}

	public SitDownRestaurants(int resultSitDownRestaurantId, String name, String description, String menu, String hours,
			boolean active, CuisineType cuisineType, String street1, String street2, String city, String state, int zip,
			Companies companyName, int capacity2) {
		// TODO Auto-generated constructor stub
		super(name, description, menu, hours, active, cuisineType, street1, street2, city, state, zip, companyName);
		this.capacity = capacity;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
}