package Review.tools;
import Review.dal.*;
import Review.model.*;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;


/**
 * main() runner, used for the app demo.
 * 
 * Instructions:
 * 1. Create a new MySQL schema and then run the CREATE TABLE statements from lecture:
 * http://goo.gl/86a11H.
 * 2. Update ConnectionManager with the correct user, password, and schema.
 */
public class Inserter {

	public static void main(String[] args) throws SQLException {
		// DAO instances.
		UsersDao usersDao = UsersDao.getInstance();
		CreditCardsDao creditCardsDao = CreditCardsDao.getInstance();
		RestaurantsDao restaurantsDao = RestaurantsDao.getInstance();
		SitDownRestaurantsDao sitDownRestaurantsDao = SitDownRestaurantsDao.getInstance();
		TakeOutRestaurantsDao takeOutRestaurantsDao = TakeOutRestaurantsDao.getInstance();
		FoodCartRestaurantsDao foodCartRestaurantsDao = FoodCartRestaurantsDao.getInstance();
		CompaniesDao companiesDao = CompaniesDao.getInstance();
		ReviewsDao reviewsDao = ReviewsDao.getInstance();
		RecommendationsDao recommendationsDao = RecommendationsDao.getInstance();
		ReservationsDao reservationsDao = ReservationsDao.getInstance();
		
		// INSERT objects from our model.
		Users user1 = new Users("Bruce","password","Bruce","C","bruce@mail.com","5555555");
		user1 = usersDao.create(user1);
		Users user2 = new Users("TT","password","Tony","D","tony@mail.com","5555555");
		user2 = usersDao.create(user2);
		Users user3 = new Users("DK","password","Daniel","K","dan@mail.com","5555555");
		user3 = usersDao.create(user3);
		Users user4 = new Users("James","password","James","M","james@mail.com","5555555");
		user4 = usersDao.create(user4);
		Users user5 = new Users("Steve","password","Steve","N","steve@mail.com","5555555");
		user5 = usersDao.create(user5);

		Companies company1 = new Companies("company1","about company1");
		company1 = companiesDao.create(company1);
		Companies company2 = new Companies("company2","about company2");
		company2 = companiesDao.create(company2);
		Companies company3 = new Companies("company3","about company3");
		company3 = companiesDao.create(company3);



		SitDownRestaurants sitDownRestaurant1 = new SitDownRestaurants("restaurant1","about restaurant","menu","hours",true,Restaurants.CuisineType.AFRICAN,"street1","street2","seattle","wa",98195,company1,100);
		sitDownRestaurant1 = sitDownRestaurantsDao.create(sitDownRestaurant1);
		SitDownRestaurants sitDownRestaurant2 = new SitDownRestaurants("restaurant2","about restaurant","menu","hours",true,Restaurants.CuisineType.AMERICAN,"street1","street2","seattle","wa",98195,company1,200);
		sitDownRestaurant2 = sitDownRestaurantsDao.create(sitDownRestaurant2);
		SitDownRestaurants sitDownRestaurant3 = new SitDownRestaurants("restaurant3","about restaurant","menu","hours",true,Restaurants.CuisineType.ASIAN,"street1","street2","seattle","wa",98195,company1,300);
		sitDownRestaurant3 = sitDownRestaurantsDao.create(sitDownRestaurant3);

		TakeOutRestaurants takeOutRestaurant1 = new TakeOutRestaurants("restaurant4","about restaurant","menu","hours",true,Restaurants.CuisineType.EUROPEAN,"street1","street2","seattle","wa",98195,company1,60);
		takeOutRestaurant1 = takeOutRestaurantsDao.create(takeOutRestaurant1);
		TakeOutRestaurants takeOutRestaurant2 = new TakeOutRestaurants("restaurant5","about restaurant","menu","hours",true,Restaurants.CuisineType.HISPANIC,"street1","street2","seattle","wa",98195,company1,90);
		takeOutRestaurant2 = takeOutRestaurantsDao.create(takeOutRestaurant2);

		FoodCartRestaurants foodCartRestaurant1 = new FoodCartRestaurants("restaurant6","about restaurant","menu","hours",true,Restaurants.CuisineType.HISPANIC,"street1","street2","bellevue","wa",98008,company2,true);
		foodCartRestaurant1 = foodCartRestaurantsDao.create(foodCartRestaurant1);
		FoodCartRestaurants foodCartRestaurant2 = new FoodCartRestaurants("restaurant7","about restaurant","menu","hours",true,Restaurants.CuisineType.HISPANIC,"street1","street2","bellevue","wa",98008,company2,true);
		foodCartRestaurant2 = foodCartRestaurantsDao.create(foodCartRestaurant2);
		FoodCartRestaurants foodCartRestaurant3 = new FoodCartRestaurants("restaurant8","about restaurant","menu","hours",true,Restaurants.CuisineType.HISPANIC,"street1","street2","bellevue","wa",98008,company2,true);
		foodCartRestaurant3 = foodCartRestaurantsDao.create(foodCartRestaurant3);
		FoodCartRestaurants foodCartRestaurant4 = new FoodCartRestaurants("restaurant9","about restaurant","menu","hours",true,Restaurants.CuisineType.AMERICAN,"street1","street2","bellevue","wa",98008,company2,true);
		foodCartRestaurant4 = foodCartRestaurantsDao.create(foodCartRestaurant4);
		FoodCartRestaurants foodCartRestaurant5 = new FoodCartRestaurants("restaurant10","about restaurant","menu","hours",true,Restaurants.CuisineType.AMERICAN,"street1","street2","bellevue","wa",98008,company3,false);
		foodCartRestaurant5 = foodCartRestaurantsDao.create(foodCartRestaurant5);

		Restaurants restaurant1 = sitDownRestaurant1;
		Restaurants restaurant2 = sitDownRestaurant2;
		Restaurants restaurant3 = sitDownRestaurant3;
		Restaurants restaurant4 = takeOutRestaurant1;
		Restaurants restaurant5 = takeOutRestaurant2;
		Restaurants restaurant6 = foodCartRestaurant1;
		Restaurants restaurant7 = foodCartRestaurant2;
		Restaurants restaurant8 = foodCartRestaurant3;
		Restaurants restaurant9 = foodCartRestaurant4;
		Restaurants restaurant10 = foodCartRestaurant5;

		Date date = new Date();
		CreditCards creditCard1 = new CreditCards(349943211, date, user1);
		creditCard1 = creditCardsDao.create(creditCard1);
		CreditCards creditCard2 = new CreditCards(348843212, date, user1);
		creditCard2 = creditCardsDao.create(creditCard2);
		CreditCards creditCard3 = new CreditCards(379943213, date, user1);
		creditCard3 = creditCardsDao.create(creditCard3);
		CreditCards creditCard4 = new CreditCards(601143214, date, user1);
		creditCard4 = creditCardsDao.create(creditCard4);
		CreditCards creditCard5 = new CreditCards(601143215, date, user1);
		creditCard5 = creditCardsDao.create(creditCard5);
		CreditCards creditCard6 = new CreditCards(644143216, date, user1);
		creditCard6 = creditCardsDao.create(creditCard6);
		CreditCards creditCard7 = new CreditCards(645143217, date, user1);
		creditCard7 = creditCardsDao.create(creditCard7);
		CreditCards creditCard8 = new CreditCards(519943218, date, user1);
		creditCard8 = creditCardsDao.create(creditCard8);
		CreditCards creditCard9 = new CreditCards(549943219, date, user1);
		creditCard9 = creditCardsDao.create(creditCard9);
		CreditCards creditCard10 = new CreditCards(549943211, date, user1);
		creditCard10 = creditCardsDao.create(creditCard10);
		CreditCards creditCard11 = new CreditCards(549943212, date, user1);
		creditCard11 = creditCardsDao.create(creditCard11);
		CreditCards creditCard12 = new CreditCards(449943213, date, user1);
		creditCard12 = creditCardsDao.create(creditCard12);
		CreditCards creditCard13 = new CreditCards(449943214, date, user1);
		creditCard13 = creditCardsDao.create(creditCard13);

		
		Reviews review1 = new Reviews(date,"Delightful!",5.0,user1,restaurant1);
		review1 = reviewsDao.create(review1);
		Reviews review2 = new Reviews(date,"Superb!",5.0,user1,restaurant2);
		review2 = reviewsDao.create(review2);
		Reviews review3 = new Reviews(date,"Superb!",5.0,user1,restaurant9);
		review3 = reviewsDao.create(review3);
		Reviews review4 = new Reviews(date,"Not good",1.0,user4,restaurant9);
		review4 = reviewsDao.create(review4);
		Reviews review5 = new Reviews(date,"Not good at all",1.0,user4,restaurant10);
		review5 = reviewsDao.create(review5);

		Recommendations recommendation1 = new Recommendations(user1,restaurant1);
		recommendation1 = recommendationsDao.create(recommendation1);
		Recommendations recommendation2 = new Recommendations(user1,restaurant2);
		recommendation2 = recommendationsDao.create(recommendation2);
		Recommendations recommendation3 = new Recommendations(user1,restaurant3);
		recommendation3 = recommendationsDao.create(recommendation3);
		Recommendations recommendation4 = new Recommendations(user1,restaurant4);
		recommendation4 = recommendationsDao.create(recommendation4);
		Recommendations recommendation5 = new Recommendations(user1,restaurant5);
		recommendation5 = recommendationsDao.create(recommendation5);
		Recommendations recommendation6 = new Recommendations(user3,restaurant2);
		recommendation6 = recommendationsDao.create(recommendation6);
		Recommendations recommendation7 = new Recommendations(user3,restaurant3);
		recommendation7 = recommendationsDao.create(recommendation7);
		Recommendations recommendation8 = new Recommendations(user2,restaurant3);
		recommendation8 = recommendationsDao.create(recommendation8);

		Reservations reservation1 = new Reservations(date,date,2,user1,sitDownRestaurant1);
		reservation1 = reservationsDao.create(reservation1);
		Reservations reservation2 = new Reservations(date,date,2,user1,sitDownRestaurant1);
		reservation2 = reservationsDao.create(reservation2);
		Reservations reservation3 = new Reservations(date,date,2,user1,sitDownRestaurant1);
		reservation3 = reservationsDao.create(reservation3);
		Reservations reservation4 = new Reservations(date,date,2,user1,sitDownRestaurant2);
		reservation4 = reservationsDao.create(reservation4);
		Reservations reservation5 = new Reservations(date,date,2,user1,sitDownRestaurant2);
		reservation5 = reservationsDao.create(reservation5);
		Reservations reservation6 = new Reservations(date,date,2,user2,sitDownRestaurant3);
		reservation6 = reservationsDao.create(reservation6);
		Reservations reservation7 = new Reservations(date,date,2,user2,sitDownRestaurant1);
		reservation7 = reservationsDao.create(reservation7);
		Reservations reservation8 = new Reservations(date,date,2,user2,sitDownRestaurant2);
		reservation8 = reservationsDao.create(reservation8);
		Reservations reservation9 = new Reservations(date,date,2,user2,sitDownRestaurant3);
		reservation9 = reservationsDao.create(reservation9);

		// READ.
		Users u1 = usersDao.getUserByUserName("bruce");
		System.out.format("Reading user: u:%s p:%s f:%s l:%s e:%s p:%s \n",
			u1.getUserName(), u1.getPassword(), u1.getFirstName(), u1.getLastName(), u1.getEmail(), u1.getPhone());

		CreditCards card1 = creditCardsDao.getCreditCardByCardNumber(349943211);
		System.out.format("Reading creditCard: c:%s x:%s u:%s \n",
			card1.getCardNumber(), card1.getExpiration(), card1.getUserName().getUserName());

		List<CreditCards> cList1 = creditCardsDao.getCreditCardsByUserName("Bruce");
		for(CreditCards c : cList1) {
			System.out.format("Looping creditCards: c:%s x:%s u:%s \n",
				c.getCardNumber(), c.getExpiration(), c.getUserName().getUserName());
		}

		Companies comp1 = companiesDao.getCompanyByCompanyName("company1");
		System.out.format("Reading company: n:%s a:%s \n",
			comp1.getCompanyName(), comp1.getAbout());

		Restaurants rest1 = restaurantsDao.getRestaurantById(3);
		System.out.format("Reading restaurant: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s \n",
			rest1.getRestaurantId(), rest1.getName(), rest1.getDescription(), rest1.getMenu(), rest1.getHours(), rest1.isActive(),
			rest1.getCuisineType(), rest1.getStreet1(), rest1.getStreet2(), rest1.getCity(), rest1.getState(),
			rest1.getZip(), rest1.getCompanyName().getCompanyName());

		
		List<Restaurants> rList1 = restaurantsDao.getRestaurantsByCuisine(Restaurants.CuisineType.HISPANIC);
		for(Restaurants r : rList1) {
			System.out.format("Reading restaurant: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s \n",
			r.getRestaurantId(), r.getName(), r.getDescription(), r.getMenu(), r.getHours(), r.isActive(),
			Restaurants.CuisineType.HISPANIC, r.getStreet1(), r.getStreet2(),r.getCity(), r.getState(),
			r.getZip(), r.getCompanyName().getCompanyName());
		}

		List<Restaurants> rList2 = restaurantsDao.getRestaurantsByCompanyName("company1");
		for(Restaurants r : rList2) {
			System.out.format("Reading restaurant: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s \n",
			r.getRestaurantId(), r.getName(), r.getDescription(), r.getMenu(), r.getHours(), r.isActive(),
			r.getCuisineType(), r.getStreet1(), r.getStreet2(),r.getCity(), r.getState(),
			r.getZip(), "company1");
		}

		SitDownRestaurants sRest1 = sitDownRestaurantsDao.getSitDownRestaurantById(3);
		System.out.format("Reading sitDownRestaurant: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s c:%s \n",
			sRest1.getRestaurantId(), sRest1.getName(), sRest1.getDescription(), sRest1.getMenu(), sRest1.getHours(), sRest1.isActive(),
			sRest1.getCuisineType(), sRest1.getStreet1(), sRest1.getStreet2(), sRest1.getCity(), sRest1.getState(),
			sRest1.getZip(), sRest1.getCompanyName().getCompanyName(), sRest1.getCapacity());

		List<SitDownRestaurants> sList1 = sitDownRestaurantsDao.getSitDownRestaurantsByCompanyName("company1");
		for(SitDownRestaurants s : sList1) {
			System.out.format("Reading sitDownRestaurants: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s \n",
			s.getRestaurantId(), s.getName(), s.getDescription(), s.getMenu(), s.getHours(), s.isActive(),
			s.getCuisineType(), s.getStreet1(), s.getStreet2(),s.getCity(), s.getState(),
			s.getZip(), "company1", s.getCapacity());
		}

		TakeOutRestaurants tRest1 = takeOutRestaurantsDao.getTakeOutRestaurantById(4);
		System.out.format("Reading takeOutRestaurant: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s c:%s \n",
			tRest1.getRestaurantId(), tRest1.getName(), tRest1.getDescription(), tRest1.getMenu(), tRest1.getHours(), tRest1.isActive(),
			tRest1.getCuisineType(), tRest1.getStreet1(), tRest1.getStreet2(), tRest1.getCity(), tRest1.getState(),
			tRest1.getZip(), tRest1.getCompanyName().getCompanyName(), tRest1.getMaxWaitTime());

		List<TakeOutRestaurants> tList1 = takeOutRestaurantsDao.getTakeOutRestaurantsByCompanyName("company1");
		for(TakeOutRestaurants t : tList1) {
			System.out.format("Reading takeOutRestaurants: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s \n",
			t.getRestaurantId(), t.getName(), t.getDescription(), t.getMenu(), t.getHours(), t.isActive(),
			t.getCuisineType(), t.getStreet1(), t.getStreet2(),t.getCity(), t.getState(),
			t.getZip(), "company1", t.getMaxWaitTime());
		}

		FoodCartRestaurants fRest1 = foodCartRestaurantsDao.getFoodCartRestaurantById(7);
		System.out.format("Reading foodCartRestaurant: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s c:%s \n",
			fRest1.getRestaurantId(), fRest1.getName(), fRest1.getDescription(), fRest1.getMenu(), fRest1.getHours(), fRest1.isActive(),
			fRest1.getCuisineType(), fRest1.getStreet1(), fRest1.getStreet2(), fRest1.getCity(), fRest1.getState(),
			fRest1.getZip(), fRest1.getCompanyName().getCompanyName(), fRest1.isLicensed());

		List<FoodCartRestaurants> fList1 = foodCartRestaurantsDao.getFoodCartRestaurantsByCompanyName("company3");
		for(FoodCartRestaurants f : fList1) {
			System.out.format("Reading foodCartRestaurants: i:%s n:%s d:%s m:%s h:%s a:%s c:%s s:%s s:%s c:%s s:%s z:%s c:%s \n",
			f.getRestaurantId(), f.getName(), f.getDescription(), f.getMenu(), f.getHours(), f.isActive(),
			f.getCuisineType(), f.getStreet1(), f.getStreet2(),f.getCity(), f.getState(),
			f.getZip(), "company3", f.isLicensed());
		}

		Reviews rev1 = reviewsDao.getReviewById(2);
		System.out.format("Reading review: i:%s d:%s c:%s r:%s u:%s r:%s \n",
			rev1.getReviewId(), rev1.getCreated(), rev1.getContent(), rev1.getRating(), rev1.getUserName().getUserName(),
			rev1.getRestaurantId().getRestaurantId());

		List<Reviews> revList1 = reviewsDao.getReviewsByUserName("Bruce");
		for (Reviews r : revList1) {
			System.out.format("Reading reviews: i:%s d:%s c:%s r:%s u:%s r:%s \n",
			r.getReviewId(), r.getCreated(), r.getContent(), r.getRating(), "Bruce",
			r.getRestaurantId().getRestaurantId());
		}

		List<Reviews> revList2 = reviewsDao.getReviewsByRestaurantId(9);
		for (Reviews r : revList2) {
			System.out.format("Reading reviews: i:%s d:%s c:%s r:%s u:%s r:%s \n",
			r.getReviewId(), r.getCreated(), r.getContent(), r.getRating(), r.getUserName().getUserName(),
			r.getRestaurantId().getRestaurantId());
		}

		Recommendations rec1 = recommendationsDao.getRecommendationById(2);
		System.out.format("Reading recommendation: i:%s u:%s r:%s \n",
			rec1.getRecommendationId(), rec1.getUserName().getUserName(), rec1.getRestaurantId().getRestaurantId());

		List<Recommendations> recList1 = recommendationsDao.getRecommendationsByUserName("Bruce");
		for (Recommendations r : recList1) {
			System.out.format("Reading recommendations: i:%s u:%s r:%s \n",
				r.getRecommendationId(), "Bruce", r.getRestaurantId().getRestaurantId());
		}

		List<Recommendations> recList2 = recommendationsDao.getRecommendationsByRestaurantId(3);
		for (Recommendations r : recList2) {
			System.out.format("Reading recommendations: i:%s u:%s r:%s \n",
				r.getRecommendationId(), r.getUserName().getUserName(), r.getRestaurantId().getRestaurantId());
		}


		Reservations res1 = reservationsDao.getReservationById(2);
		System.out.format("Reading reservation: i:%s s:%s e:%s s:%s u:%s s:%s \n",
			res1.getReservationId(), res1.getStart(), res1.getEnd(), res1.getSize(), res1.getUserName().getUserName(), 
			res1.getSitDownRestaurantId().getRestaurantId());
		List<Reservations> resList1 = reservationsDao.getReservationsByUserName("Bruce");
		for (Reservations r : resList1) {
			System.out.format("Reading reservations: i:%s s:%s e:%s s:%s u:%s s:%s \n",
				r.getReservationId(), r.getStart(), r.getEnd(), r.getSize(), "Bruce", 
				r.getSitDownRestaurantId().getRestaurantId());
		}
		List<Reservations> resList2 = reservationsDao.getReservationsBySitDownRestaurantId(2);
		for (Reservations r : resList2) {
			System.out.format("Reading reservations: i:%s s:%s e:%s s:%s u:%s s:%s \n",
				r.getReservationId(), r.getStart(), r.getEnd(), r.getSize(), r.getUserName().getUserName(), 
				r.getSitDownRestaurantId().getRestaurantId());
		}
	 }
		
}
