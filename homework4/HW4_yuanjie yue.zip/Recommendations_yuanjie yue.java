package Review.model;

public class Recommendations {

	protected int recommendationId;
	protected Users userName;
	protected Restaurants restaurantId;
	
	public Recommendations(int recommendationId, Users userName, Restaurants restaurantId) {
		this.recommendationId = recommendationId;
		this.userName = userName;
		this.restaurantId = restaurantId;
	}

	public Recommendations(int recommendationId) {
		this.recommendationId = recommendationId;
	}

	public Recommendations(Users userName, Restaurants restaurantId) {
		this.userName = userName;
		this.restaurantId = restaurantId;
	}

	public int getRecommendationId() {
		return recommendationId;
	}

	public void setRecommendationId(int recommendationId) {
		this.recommendationId = recommendationId;
	}

	public Users getUserName() {
		return userName;
	}

	public void setUserName(Users userName) {
		this.userName = userName;
	}

	public Restaurants getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(Restaurants restaurantId) {
		this.restaurantId = restaurantId;
	}
}