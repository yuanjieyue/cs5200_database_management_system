package Review.model;

import java.util.Date;

public class CreditCards {

	protected long cardNumber;
	protected Date expiration;
	protected Users userName;
	
	public CreditCards(long cardNumber, Date expiration, Users userName) {
		this.cardNumber = cardNumber;
		this.expiration = expiration;
		this.userName = userName;
	}

	public CreditCards(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public Date getExpiration() {
		return expiration;
	}

	public void setExpiration(Date expiration) {
		this.expiration = expiration;
	}

	public Users getUserName() {
		return userName;
	}

	public void setUserName(Users userName) {
		this.userName = userName;
	}
}