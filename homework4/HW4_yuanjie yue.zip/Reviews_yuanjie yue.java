package Review.model;

import java.util.Date;
public class Reviews {

	protected int reviewId;
	protected Date created;
	protected String content;
	protected double rating;
	protected Users userName;
	protected Restaurants restaurantId;
	public Reviews(int reviewId, Date created, String content, double rating, Users userName,
			Restaurants restaurantId) {
		this.reviewId = reviewId;
		this.created = created;
		this.content = content;
		this.rating = rating;
		this.userName = userName;
		this.restaurantId = restaurantId;
	}
	public Reviews(int reviewId) {
		this.reviewId = reviewId;
	}
	public Reviews(Date created, String content, double rating, Users userName, Restaurants restaurantId) {
		this.created = created;
		this.content = content;
		this.rating = rating;
		this.userName = userName;
		this.restaurantId = restaurantId;
	}
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public Users getUserName() {
		return userName;
	}
	public void setUserName(Users userName) {
		this.userName = userName;
	}
	public Restaurants getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(Restaurants restaurantId) {
		this.restaurantId = restaurantId;
	}
}